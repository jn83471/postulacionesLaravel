

<?php $__env->startSection('content'); ?>

    <p>Nombre: <?php echo e($puestos->display_name); ?></p>
    <p>
    Estatus: 
    <?php if($puestos->Estatus==0): ?>
        Activo
    <?php else: ?>
        Desactivado
    <?php endif; ?>
            
    <form action="<?php echo e(route("puestos.update",[$puestos->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?> 
        <?php if($puestos->Estatus==0): ?>
            <button type="submit" class="btn btn-danger">Desactivar</button>
        <?php else: ?>
            <button type="submit" class="btn btn-success">Activar</button>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/puestos/show.blade.php ENDPATH**/ ?>