

<?php $__env->startSection('content'); ?>
<div class="clearfix">
    <a href="<?php echo e(route("puestos.create")); ?>" class="btn btn-primary ">Add</a>
</div>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Estatus</th>
                <th scope="col">Accion</th>
              </tr>
            </thead>
            <tbody id="content">
                <?php $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class='<?php echo e(($p->Estatus==0)?"bg-success":(($p->Estatus==1)?"bg-danger":"")); ?>'>
                    <th scope="row"><a href="<?php echo e(route("puestos.show",[$p->id])); ?>"><?php echo e($p->id); ?></a> </th>
                    <td><?php echo e($p->display_name); ?></td>
                    <td>
                        <?php if($p->Estatus==0): ?>
                            Activo
                        <?php else: ?>
                            Desactivado
                        <?php endif; ?>
                    </td>
                    <td>
                        <form action="<?php echo e(route("puestos.destroy",[$p->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('delete')); ?> 
                            <?php if($p->Estatus==0): ?>
                                <button type="submit" class="btn btn-danger">Desactivar</button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-success">Activar</button>
                            <?php endif; ?>
                        </form>
                        <a href="<?php echo e(route("puestos.edit",[$p->id])); ?>" class="btn btn-primary mt-2">Editar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
          </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/puestos/index.blade.php ENDPATH**/ ?>