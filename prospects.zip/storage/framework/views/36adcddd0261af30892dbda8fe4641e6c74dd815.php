

<?php $__env->startSection('content'); ?>

<div class="row">
  
    <div class="col-lg-8 col-lg-offset-2">

      <form id="contact-form" method="post" action="<?php echo e(route("puestos.update",[$puestos->id])); ?>" role="form">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

      <div class="messages"></div>

      <div class="controls">

        <div class="row">
          <div class="col-12">
            <div class="form-group">
              <label for="form_name">Nombre *</label>
              <input id="form_name" type="text" name="nombre" value="<?php echo e($puestos->display_name); ?>" class="form-control" placeholder="Favor el nombre del puesto." required="required" data-error="Firstname is required.">
              <div class="help-block with-errors"></div>
            </div>
          </div>
          <div class="col-12 mt-2">
            <div class="form-group">
              <label for="active">Estatus</label>
              <select name="active" id="active" class="form-control">
                <option value="0" <?php echo e(($puestos->Estatus==0)?"selected":""); ?>>Activo</option>
                <option value="1" <?php echo e(($puestos->Estatus==1)?"selected":""); ?>>Desactivado</option>
              </select>
              <div class="help-block with-errors"></div>
            </div>
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary mt-3">Enviar</button>
      </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/puestos/edit.blade.php ENDPATH**/ ?>