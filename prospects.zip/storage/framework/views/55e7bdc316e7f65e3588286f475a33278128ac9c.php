

<?php $__env->startSection('content'); ?>
<div class="clearfix">
    <a href="<?php echo e(route("usuario.create")); ?>" class="btn btn-primary float-end">Add</a>
</div>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Email</th>
                <th scope="col">Accion</th>
              </tr>
            </thead>
            <tbody id="content">
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><a href="<?php echo e(route("usuario.show",[$p->id])); ?>"><?php echo e($p->id); ?></a> </th>
                    <td><?php echo e($p->name); ?></td>
                    <td>
                        <?php echo e($p->email); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route("usuario.edit",[$p->id])); ?>" class="btn btn-primary mt-2">Editar</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
          </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/users/index.blade.php ENDPATH**/ ?>