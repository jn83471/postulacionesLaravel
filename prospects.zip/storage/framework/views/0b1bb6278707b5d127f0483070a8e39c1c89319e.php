<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <label for="search">Postulantes</label>
        <input type="text" id="search" placeholder="Buscar postulantes" class="form-control">
    </div>
</div>
<div class="table-responsive">
    <table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Nombre</th>
        <th scope="col">Calle</th>
        <th scope="col">Número</th>
        <th scope="col">Colonia</th>
        <th scope="col">Código postal</th>
        <th scope="col">Email</th>
        <th scope="col">Teléfono</th>
        <th scope="col">Rfc</th>
        <th scope="col">Puesto</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody id="content">
        <?php $__currentLoopData = $prospect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class='<?php echo e(($p->Estatus==1)?"bg-success":(($p->Estatus==2)?"bg-danger":"")); ?>'>
            <th scope="row"><a href="<?php echo e(route("prospects.show",[$p->id])); ?>"><?php echo e($p->id); ?></a> </th>
            <td><?php echo e($p->apellidoPaterno." ".$p->apellidoMaterno." ".$p->nombre); ?></td>
            <td><?php echo e($p->calle); ?></td>
            <td><?php echo e($p->numero); ?></td>
            <td><?php echo e($p->colonia); ?></td>
            <td><?php echo e($p->cp); ?></td>
            <td><?php echo e($p->email); ?></td>
            <td><?php echo e($p->phone); ?></td>
            <td><?php echo e($p->rfc); ?></td>
            <td><?php echo e($p->hasPuesto->display_name); ?></td>
            <td>
                <?php if($p->Estatus==0): ?>
                <form action="<?php echo e(route("prospects.update",[$p->id])); ?>" method="post"><?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <button type="submit" class="btn btn-success" value="acept" name="acept">Autorizar</button>
                </form>
                <a href="<?php echo e(route("prospects.show",[$p->id])); ?>" class="btn btn-danger mt-1">Rechazar</a>
                <?php endif; ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</div>
<?php if(!$prospect->onFirstPage()): ?>
<a href="<?php echo e($prospect->previousPageUrl()); ?>" class="btn btn-primary" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
    Página anterior
</a>
<?php endif; ?>
        <?php if($prospect->hasMorePages()): ?>

                <a href="<?php echo e($prospect->nextPageUrl()); ?>" class="btn btn-primary" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    Siguiente página
                </a>
        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/home.blade.php ENDPATH**/ ?>