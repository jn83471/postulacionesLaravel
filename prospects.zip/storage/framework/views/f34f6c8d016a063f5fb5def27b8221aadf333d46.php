

<?php $__env->startSection('content'); ?>
            <p>Nombre: <?php echo e($prospect->apellidoPaterno." ".$prospect->apellidoMaterno." ".$prospect->nombre); ?></p>
            <p>Calle: <?php echo e($prospect->calle); ?></p>
            <p>Número: <?php echo e($prospect->numero); ?></p>
            <p>Colonia: <?php echo e($prospect->colonia); ?></p>
            <p>Código postal:<?php echo e($prospect->cp); ?></p>
            <p>Email: <?php echo e($prospect->email); ?></p>
            <p>Teléfono: <?php echo e($prospect->phone); ?></p>
            <p>RFC: <?php echo e($prospect->rfc); ?></p>
            <p>Puesto: <?php echo e($prospect->hasPuesto->display_name); ?></p>
            <?php if($prospect->Estatus==2): ?>
            <p>Motivo: <pre><?php echo e($prospect->Motive); ?></pre></p>
            <?php endif; ?>
            <ul class="list-group">
                <?php $__currentLoopData = $prospect->hasfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item position-relative overflow-hidden" style="text-overflow: ellipsis;"><?php echo e($fila->src); ?> <a href="/<?php echo e($fila->src); ?>" class="position-absolute top-0 end-0 m-2" target="_blank"><i class="fas fa-external-link-alt"></i></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
            <?php if($prospect->Estatus==0): ?>
                <form action="<?php echo e(route("prospects.update",[$prospect->id])); ?>" method="post"><?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <button type="submit" class="btn btn-success" value="acept" name="acept">Autorizar</button>
                    <div class="mt-2">
                        <textarea name="Razor" class="form-control" placeholder="Razón del rachazo"></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger mt-1 d-block" value="reset" name="acept">Rechazar</button>
                </form>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../../templates/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prospects\resources\views/admin/prospects/show.blade.php ENDPATH**/ ?>